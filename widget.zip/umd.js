import selfMount from "./src/main";

export { selfMount };