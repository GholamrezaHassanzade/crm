const path = require("path");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const dotenv = require("dotenv");
const webpack = require("webpack");

dotenv.config();

module.exports = {
    entry: {
        app: "./umd.js",
    },
     output: {
        path: path.resolve(__dirname, "dist"),
        filename: "[name].bundle.js",
        library: 'WebChat',
        libraryTarget: 'umd',
       /*  clean: true, */
    },
    module: {
        rules: [
            {
                test: /\.(js|jsx)$/,
                exclude: /(node_modules|bower_components)/,
                use: ['babel-loader'],
              },
            {
                test: /\.css$/i,
                use: ["style-loader", "css-loader"],
            },
            {
                test: /\.scss$/i,
                use: ["style-loader", "css-loader", "sass-loader"],
            },
            {
                test: /\.(png|jpe|jpg|svg|mp3|wav|jepg?g|gif)$/i,
                type: "asset/resource",
            },
            {
                test: /\.(eot|ttf|woff|woff2)$/i,
                type: "asset/inline",
            },
            /* {
                test: /\.m?js$/i,
                exclude: /(node_modules|bower_components)/,
                use: ["babel-loader"],
            }, */
        ],
    },
    resolve: {
        extensions: [".js", ".jsx"],
    },
    performance: {
        hints: false,
    },
    
    plugins: [
        new HtmlWebpackPlugin({
            title: "Web Chat Widget Test",
            filename: "index.html",
            template: "./public/index.html",
            showErrors: true,
        }),
        new webpack.DefinePlugin({
            "process.env": JSON.stringify(process.env),
        }),
       /*  new webpack.optimize.UglifyJsPlugin({
            include: /\.min\.js$/,
            minimize: true
          }) */
    ],
   
};
