import React from "react";

export const ChoseFileSvg = ({ width = "32px", height = "32px" }) => {
    return (
        <svg
            width={width}
            height={height}
            viewBox="0 0 32 32"
            fill="none"
            //xmlns="http://www.w3.org/2000/svg"
        >
            <g id="Frame 4">
                <path
                    id="Vector 59"
                    d="M13.3333 13.3913V20.7807C13.3333 21.9773 14.3034 22.9474 15.5 22.9474V22.9474C16.6966 22.9474 17.6667 21.9773 17.6667 20.7807V8.33333C17.6667 5.9401 15.7266 4 13.3333 4V4C10.9401 4 9 5.9401 9 8.33333V21.5C9 25.0899 11.9101 28 15.5 28V28C19.0899 28 22 25.0899 22 21.5V14.1053"
                    stroke="#666869"
                    strokeLinecap="round"
                />
            </g>
        </svg>
    );
};
