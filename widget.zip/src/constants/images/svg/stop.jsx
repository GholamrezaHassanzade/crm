import React from "react";

export const StopSvg = () => {
    return (
        <svg
            width="10"
            height="12"
            viewBox="0 0 10 12"
            fill="none"
           // xmlns="http://www.w3.org/2000/svg"
        >
            <path
                id="Vector 178"
                d="M1 1V11M9 1V11"
                stroke="#5E5390"
                strokeWidth="2"
                strokeLinecap="round"
            />
        </svg>
    );
};
