import React from "react";

export const ArrowSvg = () => {
    return (
        <svg
            width="48"
            height="48"
            viewBox="0 0 48 48"
            fill="none"
            // xmlns="http://www.w3.org/2000/svg"
        >
            <g id="Group 53">
                <g id="Group 88">
                    <path
                        id="Vector 15"
                        d="M28 31L21.0751 24.9407C20.5059 24.4427 20.5059 23.5573 21.0751 23.0593L28 17"
                        stroke="#191919"
                        strokeWidth="1.25"
                        strokeLinecap="round"
                    />
                </g>
            </g>
        </svg>
    );
};
