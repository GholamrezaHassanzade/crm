import React from "react";

export const AttachmentSVG = ({stroke = "#2f428e"}) => {
    return (
        <svg
            width="24"
            height="24"
            viewBox="0 0 32 32"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
        >
            <g id="Frame 14">
                <path
                    id="Rectangle 395"
                    d="M20 27.25H12C10.2051 27.25 8.75 25.7949 8.75 24V8C8.75 6.20508 10.2051 4.75 12 4.75H17C17.4369 4.75 17.8552 4.92662 18.1599 5.23972L22.8804 10.0902C23.1174 10.3338 23.25 10.6602 23.25 11V24C23.25 25.7949 21.7949 27.25 20 27.25Z"
                    stroke={stroke}
                    strokeWidth="1.5"
                />
            </g>
        </svg>
    );
};
