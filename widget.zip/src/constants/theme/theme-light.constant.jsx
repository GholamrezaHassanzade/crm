// * Import Tools
import { rgba } from "polished";

const BASE_COLORS = {
    WHITE: "#ffffff",
    BLACK: "#000000",
};
/* "rgba(94, 83, 144, 1)" */ /* rgba(47, 66, 142, 1) */
const SYSTEM_THEME_COLORS = {
    PRIMARY: "rgba(94, 83, 144, 1)",
    SURFACE_BORDER: "#eeeeee",
};

const SYSTEM_THEME_COLORS_PALE = {
    BOX_SHADOW_PRIMARY: rgba(BASE_COLORS.BLACK, 0.1),
    BOX_SHADOW_SECONDEY: rgba(BASE_COLORS.BLACK, 0.25),
};
export const THEME_LIGHT = {
    ...BASE_COLORS,
    ...SYSTEM_THEME_COLORS,
    ...SYSTEM_THEME_COLORS_PALE,
};
