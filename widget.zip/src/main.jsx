import React from "react";
import ReactDOM from "react-dom/client";

import App from "./components/App";

/* import "./assets/font/font.css" */
import "./style.scss"

function selfMount(props = null, element = null) {
    /* const HIRAX_ID = Math.floor(Math.random() * 1000000000000); */

    const load = () => {
        if (element === null) {
            const node = document.createElement("div");
            node.setAttribute("id", `hirax_chatbot`);
            document.body.appendChild(node);
        }
        const root =
            element ||
            ReactDOM.createRoot(document.getElementById(`hirax_chatbot`));
        const webchatPro = React.createElement(App, props);
        root.render(webchatPro);
    };
    if (document.readyState === "complete") {
        load();
    } else {
        window.addEventListener("load", () => {
            load();
        });
    }
}

export default selfMount;

/* export const selfMount = (element = null) => {
    const load = () => {
        if (element === null) {
            const node = document.createElement("div");
            node.setAttribute("id", "hirax_chatbot");
            document.body.appendChild(node);
        }
        const root =
            element ||
            ReactDOM.createRoot(document.getElementById("hirax_chatbot"));
        const webchatPro = React.createElement(App);
        root.render(webchatPro);
    };
    if (document.readyState === "complete") {
        load();
    } else {
        window.addEventListener("load", () => {
            load();
        });
    }
};
selfMount() */