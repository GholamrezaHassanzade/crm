export { HeaderWidgetComponent as HeaderWidget } from "./header/header.widget.component";
export { ProgressWidgetComponent as ProgressWidget } from "./progress/progress.widget.component";
