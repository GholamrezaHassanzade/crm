// * Import Tools
import styled from "@emotion/styled/macro";

/*
 * TODO
 */
const ProgressContainer = styled.div`
    display: flex;
    align-items: center;
    padding: 8px 16px;
    width: 100%;
    position: absolute;
    bottom: 0;
    background-color: ${({ theme }) => theme.WHITE};
`;

const ProgressRow = styled.div`
    width: 100%;
    box-shadow: 0px 0px 8px 0px rgba(0, 0, 0, 0.25);
    border-radius: 16px;
    display: flex;
    flex-direction: column;
    gap: 8px;
    padding: 12px 24px;
`;

const ProgressInformation = styled.div`
    align-items: center;
    display: flex;
    justify-content: space-between;
`;
const ProgressInformationRight = styled.div`
    align-items: center;
    display: flex;
    gap: 8px;
`;
const ProgressInformationRightImage = styled.div``;
const ProgressInformationRightInfo = styled.div`
    display: flex;
    flex-direction: column;
`;
const ProgressInformationRightInfoName = styled.span`
    color: #666869;
    font-family: YekanBakh;
    font-size: 12px;
    font-style: normal;
    font-weight: 400;
    line-height: 20px;
    text-align: right;
`;
const ProgressInformationRightInfoSize = styled.span`
    color: #666869;
    font-family: YekanBakh;
    font-size: 10px;
    font-style: normal;
    font-weight: 400;
    line-height: 16px;
    text-align: right;
`;
const ChoseFileBtn = styled.label`
    border: 0 !important;
    outline: 0 !important;
    background-color: transparent !important;
    cursor: pointer !important;
    width: 32px !important;
    height: 32px !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    /*  svg {
        width: 20px !important;
        height: 20px !important;
    } */
`;
const ProgressBarContainer = styled.div`
    align-items: center;
    display: flex;
    flex-direction: row-reverse;
    gap: 8px;
`;
const Progress = styled.div`
    background: #dfdde9;
    direction: ltr;
    flex: 1 1;
    height: 4px;
`;
const ProgressUpload = styled.div`
    background: #5e5390;
    height: 100%;
    width: ${({ width }) => width}%;
    //  width: 15%;
`;
const ProgressUploadTitle = styled.span`
    color: #666869;
    font-family: YekanBakh;
    font-size: 10px;
    font-style: normal;
    font-weight: 400;
    line-height: 16px;
    text-align: right;
`;
const SendProgressUpload = styled.div`
    display: flex;
    align-items: center;
    justify-content: flex-end;
`;
const SendProgressUploadBtn = styled.button`
    border: 0 !important;
    outline: 0 !important;
    cursor: pointer !important;
    width: 32px !important;
    height: 32px !important;
    background-color: ${({ theme }) => theme.PRIMARY} !important;
    border-radius: 50% !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
`;
export const ProgressWidgetComponentStyle = {
    ProgressContainer,
    ProgressRow,
    ProgressInformation,
    ProgressInformationRight,
    ProgressInformationRightImage,
    ProgressInformationRightInfo,
    ProgressInformationRightInfoName,
    ProgressInformationRightInfoSize,
    ChoseFileBtn,
    ProgressBarContainer,
    Progress,
    ProgressUpload,
    ProgressUploadTitle,
    SendProgressUpload,
    SendProgressUploadBtn,
};
