import React from "react";
import { ProgressWidgetComponentStyle as S } from "./progress.widget.style.component";
import { AttachmentSVG, CloseSVG, SendFileSvg } from "../../../../constants/images";

export const ProgressWidgetComponent = ({ name, size, onClose, progress,sendUploadFile }) => {
    return (
        <S.ProgressContainer>
            <S.ProgressRow>
                <S.ProgressInformation>
                    <S.ProgressInformationRight>
                        <S.ProgressInformationRightImage>
                            <AttachmentSVG />
                        </S.ProgressInformationRightImage>
                        <S.ProgressInformationRightInfo>
                            <S.ProgressInformationRightInfoName>
                                {/*  {selectedFiles[0]?.name} */} {name}
                            </S.ProgressInformationRightInfoName>
                            <S.ProgressInformationRightInfoSize>
                                {/* {formatBytes(selectedFiles[0]?.size)} */}{" "}
                                {size}
                            </S.ProgressInformationRightInfoSize>
                        </S.ProgressInformationRightInfo>
                    </S.ProgressInformationRight>
                    <S.ChoseFileBtn
                        /* onClick={() => setSelectedFiles([])} */ onClick={
                            onClose
                        }
                    >
                        <CloseSVG fill="#000000" width="16px" height="16px" />
                    </S.ChoseFileBtn>
                </S.ProgressInformation>
                <S.ProgressBarContainer>
                    <S.Progress>
                        <S.ProgressUpload width={progress}></S.ProgressUpload>
                    </S.Progress>
                    <S.ProgressUploadTitle>{progress} %</S.ProgressUploadTitle>
                </S.ProgressBarContainer>
                <S.SendProgressUpload>
                    <S.SendProgressUploadBtn
                        disabled={progress <= 0 ? false : true}
                        onClick={sendUploadFile}
                    >
                        <SendFileSvg />
                    </S.SendProgressUploadBtn>
                </S.SendProgressUpload>
            </S.ProgressRow>
        </S.ProgressContainer>
    );
};
