import React from "react";

import { HeaderWidgetComponentStyle as S } from "./header.widget.component.style";
import { Typography } from "../../partials";
import { CloseSVG } from "../../../../constants/images";

export const HeaderWidgetComponent = ({
    baseUrl,
    name,
    appName,
    templateConfig,
    subTitle,
    onClose,
}) => {
    return (
        <S.HeaderWidget backgroundColor={templateConfig?.primaryColor}>
            <S.HeaderWidgetContiner >
                <S.AvatorWidget bgAvator={templateConfig?.avatorBg}>
                    <img src={`${baseUrl}/cdn/hirax-cdn/logo.svg`} alt="" />
                </S.AvatorWidget>
                <S.DisplayFlexBoxWidget
                    flexDirection={"column"}
                    alignItems={"flex-start"}
                >
                    <Typography fontSize={16} fonrWeight={600} titleColor={templateConfig?.titleColor}>
                        {appName}
                    </Typography>
                    {/*   {subTitle ? ( */}
                    <Typography fontSize={12} fonrWeight={500} titleColor={templateConfig?.titleColor}>
                        {name ? name : subTitle}
                    </Typography>
                    {/*   ) : null}  */}
                </S.DisplayFlexBoxWidget>
            </S.HeaderWidgetContiner>

            <S.HeaderWidgetContinerClose onClick={onClose}>
                <CloseSVG width="24px" height="24px" />
            </S.HeaderWidgetContinerClose>
        </S.HeaderWidget>
    );
};
