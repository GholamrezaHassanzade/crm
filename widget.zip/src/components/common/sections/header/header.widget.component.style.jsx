// * Import Tools
import styled from "@emotion/styled/macro";
const HeaderWidget = styled.div`
    width: 100% !important;
    background-color: ${({ theme, backgroundColor }) =>
        backgroundColor ? backgroundColor : theme.PRIMARY} !important;
    display: flex !important;
    justify-content: space-between !important;
    align-items: center !important;
`;
const HeaderWidgetContiner = styled.div`
    width: 90% !important;
    display: flex !important;
    align-items: center !important;
    gap: 5px !important;
    padding: 7px !important;
`;
const AvatorWidget = styled.div`
    width: 45px !important;
    height: 45px !important;
    border-radius: 100px !important;
    padding: 4px !important;
    margin: 5px 15px 0 !important;
    background: ${({ theme ,bgAvator}) => bgAvator ? bgAvator :theme.SURFACE_BORDER} !important;
    overflow: hidden !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
   /*  img {
    } */
`;
/*
 *@TODO
 */
const DisplayFlexBoxWidget = styled.div`
    display: flex;
    flex-direction: ${({ flexDirection }) => flexDirection ?? "unset"} !important; 
    align-items: ${({ alignItems }) => alignItems ?? "unset"} !important;
    justify-content: ${({ justifyContent }) => justifyContent ?? "unset"} !important;
    margin-bottom: ${({ marginBottom }) => `${marginBottom}px` ?? "unset"} !important;
`;

const HeaderWidgetContinerClose = styled.div`
    display: flex !important;
    justify-content: center !important;
    align-items: center !important;
    padding: 6px !important;
    cursor: pointer !important;
    height: 100% !important;
    width: 15% !important;
`;

export const HeaderWidgetComponentStyle = {
    HeaderWidget,
    HeaderWidgetContiner,
    AvatorWidget,
    DisplayFlexBoxWidget,
    HeaderWidgetContinerClose,
};
