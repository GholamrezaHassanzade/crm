// * Import Tools
import styled from "@emotion/styled/macro";

const ButtonPalyerContainer = styled.div`
    display: flex;
    justify-content: center;
    align-items: center;
    width: 32px;
    height: 32px;
    border-radius: 50%;
   /*  padding: 16px; */
    background: #CFCBDE;
    cursor: pointer;

`;
export const ButtonPlayerCompomentStyle = {
    ButtonPalyerContainer,
};
