import React from "react";
import "./button.css";
import { ButtonPlayerCompomentStyle as S } from "./button-player.componet.style";
import { Player, StopSvg } from "../../../../../constants/images";

export const ButtonPlayer = ({ play, isPlaying }) => {
    return (
        <S.ButtonPalyerContainer onClick={play}>
            {isPlaying ? <StopSvg /> : <Player />}
        </S.ButtonPalyerContainer>
    );
};
