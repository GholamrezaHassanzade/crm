// * Import Tools
import styled from "@emotion/styled/macro";

const AudioPlayerContainer = styled.div`
    width: 297px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    direction: ltr;
    gap: 8px;
`;
export const AudioPlayerCompomentStyle = {
    AudioPlayerContainer,
};
