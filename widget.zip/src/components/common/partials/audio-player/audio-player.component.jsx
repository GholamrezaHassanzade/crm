import React, { useEffect, useRef, useState } from "react";
/* import song from "./song1.mp3"; */

import { AudioPlayerCompomentStyle as S } from "./audio-player.component.style";

import "./audio.css";
import { SliderComponet } from "./slider/slider.componet";
import ControlPanel from "./controls/ControlPanel";
export const AudioPlayerComponent = ({ song }) => {
    /* console.log(song); */
    /*  console.log(song); */
    const [percentage, setPercentage] = useState(0);
    const [isPlaying, setIsPlaying] = useState(false);
    const [duration, setDuration] = useState(0);
    const [currentTime, setCurrentTime] = useState(0);

    const audioRef = useRef();
    const onChange = (e) => {
        const audio = audioRef.current;
        audio.currentTime = (audio.duration / 100) * e.target.value;
        setPercentage(e.target.value);
    };

    const play = () => {
        const audio = audioRef.current;
        audio.volume = 0.1;

        if (!isPlaying) {
            setIsPlaying(true);
            audio.play();
        }

        if (isPlaying) {
            setIsPlaying(false);
            audio.pause();
        }
    };

    const getCurrDuration = (e) => {
        const percent = (
            (e.currentTarget.currentTime / e.currentTarget.duration) *
            100
        ).toFixed(2);
        const time = e.currentTarget.currentTime;

        setPercentage(+percent);
        setCurrentTime(time.toFixed(2));
    };

    const secondsToHms = (seconds) => {
        if (!seconds) return "00 : 00";

        let duration = seconds;
        let hours = duration / 3600;
        duration = duration % 3600;

        let min = parseInt(duration / 60);
        duration = duration % 60;

        let sec = parseInt(duration);

        if (sec < 10) {
            sec = `0${sec}`;
        }
        if (min < 10) {
            min = `0${min}`;
        }

        if (parseInt(hours, 10) > 0) {
            return `${parseInt(hours, 10)} :${min} : ${sec}`;
        } else if (min == 0) {
            return `00 :${sec}`;
        } else {
            return `${min} : ${sec}:`;
        }
    };
    return (
        <S.AudioPlayerContainer>
            <ControlPanel
                play={play}
                isPlaying={isPlaying}
                duration={duration}
                currentTime={currentTime}
            />

            <div className="container__slider__timer">
                <SliderComponet percentage={percentage} onChange={onChange} />
                <div className="timer">{secondsToHms(currentTime)}</div>
            </div>
            <audio
                ref={audioRef}
                onTimeUpdate={getCurrDuration}
                onLoadedData={(e) => {
                    setDuration(e.currentTarget.duration.toFixed(2));
                }}
                type="audio/wav"
                src={song}
            ></audio>
        </S.AudioPlayerContainer>
    );
};
