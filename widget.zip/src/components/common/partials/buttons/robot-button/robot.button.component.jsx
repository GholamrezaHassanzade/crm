import React from "react";
import { RobotButtonComponentStyle as S } from "./robot.button.component.style";
import { ArrowSvg } from "../../../../../constants/images";

export const RobotButtonComponent = ({ onClick, children }) => {
    return (
        <S.MessageBoxWidgetButton onClick={onClick}>
            <S.TitleRobotButton>{children}</S.TitleRobotButton>
            <ArrowSvg />
        </S.MessageBoxWidgetButton>
    );
};
