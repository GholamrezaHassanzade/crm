// * Import Tools
import styled from "@emotion/styled/macro";

const MessageBoxWidgetButton = styled.button`
    width: 307px !important;
    border: 0 !important;
    outline: 0 !important;
    margin-bottom: 15px !important;
    padding: 15px 14px !important;
    border-radius: 16px !important;
    font-size: 13px !important;
    font-weight: 500 !important;
    color: ${({ theme }) => theme.BLACK} !important;
    background-color: ${({ theme }) => theme.WHITE} !important;
    cursor: pointer !important;
    border: 1px solid ${({ theme }) => theme.WHITE} !important;
    font-family: "YekanBakh" !important;
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;

    svg {
        width: 32px !important;
        height: 32px !important;
        stroke: #191919 !important;
    }
`;

const TitleRobotButton = styled.span``;

export const RobotButtonComponentStyle = {
    MessageBoxWidgetButton,
    TitleRobotButton,
};
