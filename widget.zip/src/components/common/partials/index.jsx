export { InputCompoment as Input } from "./inputs/input.compoment";
export { RobotButtonComponent as RobotButton } from "./buttons/robot-button/robot.button.component";

export { TypographyComponent as Typography } from "./typography/typography.component";
export { AudioPlayerComponent as AudioPlayer } from "./audio-player/audio-player.component";
