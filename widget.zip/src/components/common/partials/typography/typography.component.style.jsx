// * Import Tools
import styled from "@emotion/styled/macro";

const TitleWightHirax = styled.p`
    font-family: "YekanBakh" !important;
    margin: 0 !important;
    color: ${({ theme, titleColor }) =>
        titleColor ? titleColor : theme.WHITE} !important;
    font-size: ${({ fontSize }) => `${fontSize}px`} !important;
    font-weight: ${({ fonrWeight }) => `${fonrWeight}`} !important;
`;

export const TypographyComponentStyle = {
    TitleWightHirax,
};
