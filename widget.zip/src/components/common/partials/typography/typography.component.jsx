// * Import Casual modules
import React from "react";

//* Import style
import { TypographyComponentStyle as S } from "./typography.component.style";

export const TypographyComponent = ({ children, fontSize, fonrWeight,titleColor }) => {
    return (
        <S.TitleWightHirax fontSize={fontSize} fonrWeight={fonrWeight} titleColor={titleColor}>
            {children}
        </S.TitleWightHirax>
    );
};
