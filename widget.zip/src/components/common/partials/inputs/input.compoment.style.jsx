// * Import Tools
import styled from "@emotion/styled/macro";

const InputSendBoxWidget = styled.input`
    border: unset !important;
    outline: unset !important;
    width: 1000% !important;
    height: 43px !important;
    font-family: "YekanBakh" !important;
    background: ${({ theme }) => theme.WHITE}  !important;
    padding: 0 0px 0 16px !important;
   /*  box-shadow: 0px 0px 8px ${({ theme }) => theme.BOX_SHADOW_SECONDEY} !important;
    border-radius:  16px !important; */
`;
export const InputCompomentStyle = {
    InputSendBoxWidget,
};
