// * Import Casual modules
import React from "react";
import { InputCompomentStyle as S } from "./input.compoment.style";

// * import style

export const InputCompoment = ({ placeholder, type, onChange, value }) => {
    return (
        <S.InputSendBoxWidget
            value={value}
            onChange={onChange}
            placeholder={placeholder}
            type={type}
        />
    );
};
