import React from "react";

import { AppConfigurations } from "./config/app.configurations";
import socketIO from "socket.io-client";
import { WidgetView } from "./views/widget/widget.view";

const App = (props) => {
    const {
        zIndex,
        appName = "هیراکس",
        subTitle = "پشتیبان هوشمند",
        baseUrl,
        token,
    } = props;

    const uuid = localStorage.getItem("uuid");

    const header = {
        Authorization: `Bearer ${token}`,
        uuid: String(uuid),
    };
    const socket = socketIO.connect(`${baseUrl}/`, {
        autoConnect: true,
        extraHeaders: header,
    });
    return (
        <AppConfigurations baseUrl={baseUrl}>
            <WidgetView
            
                token={token}
                subTitle={subTitle}
                appName={appName}
                socket={socket}
                zIndex={zIndex}
                baseUrl={baseUrl}
            />
        </AppConfigurations>
    );
};

export default App;
