// * Import Casual modules
import React, { Fragment, useEffect, useRef, useState } from "react";
import moment from "jalali-moment";

// * Import Style
import { WidgetViewStyle as S } from "./widget.view.style";

import {
    AudioPlayer,
    Input,
    RobotButton,
    Typography,
} from "../../common/partials";
import {
    CommentSVG,
    CloseSVG,
    AttachmentSVG,
    LikeSVG,
    Dislike,
    RecordSVG,
    RecordAction,
    ChoseFileSvg,
    SendFileSvg,
    CloseReplySvg,
} from "../../../constants/images";
import axios from "axios";

import RecordRTC, { StereoAudioRecorder } from "recordrtc";
import { HeaderWidget, ProgressWidget } from "../../common/sections";
import { PartView } from "./part/part.view";

export const WidgetView = ({
    socket,
    zIndex,
    appName,
    subTitle,
    baseUrl,
    token,
}) => {
    /*
     *TODO Refactor
     */
    const refVoice = useRef(null);
    const recorderRef = useRef(null);
    const intervalRef = useRef(null);
    const messagesEndRef = useRef(null);

    const [isOpen, setIsOpen] = useState(false);
    const [messages, setMessages] = useState([]);
    const [name, setName] = useState("");
    const [message, setMessage] = useState("");
    const [stream, setStream] = useState(null);
    const [blob, setBlob] = useState(null);
    const [initRecording, setInitRecording] = useState(false);
    const [microphone, setMicrophone] = useState(true);
    const [count, setCount] = useState(0);
    const [begin, setBegin] = useState(false);
    const [selectedFiles, setSelectedFiles] = useState([]);
    const [progress, setProgress] = useState(0);

    const [form, setForm] = useState({
        templateConfig: {},
    });
    const { templateConfig } = form;
    // get the CancelToken object from axios
    const CancelToken = axios.CancelToken;
    // create a cancel token instance
    const cancelTokenSource = CancelToken.source();
    const scrollToBottom = () => {
        messagesEndRef.current &&
            messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    };
    useEffect(() => {
        function onConnect(res) {
            res !== "ok" ? localStorage.setItem("uuid", String(res)) : "";
        }
        socket.on("connectResponse", onConnect);
        return () => {
            socket.off("connectResponse", onConnect);
        };
    });
    useEffect(() => {
        socket.on("sendMessageFromWidgetResponse", function (res) {
            if (res?.status === "ok") {
                const newList = messages?.map((item, index) => {
                    if (index === messages.length - 1) {
                        item.buttons = [];
                    }
                    return item;
                });
                setMessages(newList);
                scrollToBottom();

                setMessages([
                    ...messages,
                    {
                        from: "me",
                        msg: res?.message,
                        timestamp: res?.timestamp,
                        id: res?.id,
                        reply_message: res?.reply_message,
                    },
                ]);
            }
        });
    });
    useEffect(() => {
        socket.on("messageToWidget", (res) => {
            /* console.log(res); */
            if (res?.reply_message) {
                setName(res?.name);
                scrollToBottom();
                setMessages([
                    ...messages,
                    {
                        from: "admin",
                        msg: res?.message,
                        timestamp: res?.timestamp,
                        buttons: res?.buttons,
                        reply_message: res?.reply_message,
                        id: res.id,
                    },
                ]);
            } else {
                setName(res?.name);
                scrollToBottom();
                setMessages([
                    ...messages,
                    {
                        from: "admin",
                        msg: res?.message,
                        timestamp: res?.timestamp,
                        buttons: res?.buttons,
                        id: res.id,
                    },
                ]);
            }
        });
    });
    
    useEffect(() => {
        const uuid = localStorage.getItem("uuid");
        const fetchData = async () => {
            let headers = {
                Authorization: `Bearer ${token}`,
            };
            let formData = new FormData();
            formData.append("uuid", uuid);
            const { data, status } = await axios.post(
                `${baseUrl}/api/hirax/chat_history`,
                formData,

                {
                    headers: headers,
                }
            );
            if (status === 200) {
                setMessages([...messages, ...data?.messages.reverse()]);
                scrollToBottom();
            }
        };
        fetchData();
    }, []);
    useEffect(() => {
        const fetchGetConfig = async () => {
            let headers = {
                Authorization: `Bearer ${token}`,
            };
            const { data, status } = await axios.get(
                `${baseUrl}/api/hirax/get_config`,
                {
                    headers: headers,
                }
            );
            if (status === 200) {
                if (data?.status === "passed") {
                    setForm({
                        ...form,
                        templateConfig: data?.widget_configs?.config,
                    });
                }
            }
        };

        if (token) {
             fetchGetConfig();
        }
    }, [token]);

    const handleShowMessagebox = () => {
        setIsOpen(true);
    };
    const handleCloseMessagebox = () => {
        setIsOpen(false);
    };
    const handleSubmitMessage = (e) => {
        e.preventDefault();
        if (message.trim()) {
            socket
                .timeout(500)
                .emit("sendMessageFromWidget", { message: message });
        }
        setMessage("");
        scrollToBottom();
    };
    const handleSendText = (payload) => {
        if (payload.trim()) {
            socket.emit("sendMessageFromWidget", { message: payload });
        }
    };

    const createShowIcon = (title) => {
        if (title === "like") {
            return (
                <S.LikeAndDisLikeContainer>
                    <S.LikeAndDisLikeWrrapper
                        onClick={() => handleSendText("/thank")}
                    >
                        <LikeSVG />
                    </S.LikeAndDisLikeWrrapper>
                    <S.LikeAndDisLikeWrrapper
                        onClick={() => handleSendText("/unsatisfaction")}
                    >
                        <Dislike />
                    </S.LikeAndDisLikeWrrapper>
                </S.LikeAndDisLikeContainer>
            );
        } /* else if (title === "dislike") {
            return;
        } */
        /* return title; */
    };
    const getTime = (timestamp) => {
        let ts = moment.unix(timestamp).format("hh:mm");
        return ts;
    };

    const renderMessages = (mes) => {
        /*  let urlRegex = /(https?:\/\/[^\s]+)/g;
        if (urlRegex) {
            return mes?.replace(urlRegex, function (url) {
                return '<a href="' + url + '" target="_blank">' + url + "</a>";
            });
        } */
        return mes;
    };

    useEffect(() => {
        socket.on("messageToWidgetEdit", function (res) {
            const newList = messages?.map((item) => {
                if (item.id === res?.id) {
                    /* let updatedItem = {
                        ...item,
                    }; */
                    /*  updatedItem.id = res?.id */
                    item.msg = res.message;
                    /*  return updatedItem; */
                }
                return item;
            });
            setMessages(newList);
        });
    });

    useEffect(() => {
        socket.on("messageToWidgetDelete", function (res) {
            const filteMessage = messages?.filter((itm) => itm?.id !== res?.id);
            setMessages(filteMessage);
        });
    });

    useEffect(() => {
        socket.on("fileToWidget", function (res) {
            scrollToBottom();
            setMessages([
                ...messages,
                {
                    from: "admin",
                    timestamp: res.timestamp,
                    msg: res.message,
                    id: res.id,
                    file: res.file,
                    reply_message: res?.reply_message,
                    buttons: res?.buttons,
                },
            ]);
        });
    });
    useEffect(() => {
        if (begin) {
            intervalRef?.current && clearInterval(intervalRef.current);

            const intervalId = setInterval(() => {
                setCount((prev) => prev + 1);
            }, 1000);
            intervalRef.current = intervalId;
        } else {
            setCount(0);
            intervalRef?.current && clearInterval(intervalRef.current);
        }
    }, [begin]);
    const startRecording = async () => {
        try {
            if ("MediaRecorder" in window) {
                const cameraStream = await navigator.mediaDevices
                    .getUserMedia({
                        audio: true,
                    })
                    .catch(function (error) {
                        setMicrophone(false);
                        setBegin(false);
                    });
                setStream(cameraStream);

                recorderRef.current = new RecordRTC(cameraStream, {
                    type: "audio",
                    mimeType: "audio/mp3",
                  /*   sampleRate: 22050, */
                    /* recorderType: StereoAudioRecorder, */
                });

                if (microphone) {
                    setInitRecording(true);
                    recorderRef.current.startRecording();
                    setBegin(true);
                }
            }
        } catch (error) {
            console.log(error);
        }
    };

    const saveRecording = () => {
        recorderRef.current.stopRecording(() => {
            setBlob(recorderRef.current.getBlob());
        });
        setInitRecording(false);
        setBegin(false);
    };

    useEffect(() => {
        if (count === 29) {
            saveRecording();
        }
    }, [count]);

    useEffect(() => {
        if (!refVoice.current) {
            return;
        }

        // refVoice.current.srcObject = stream;
    }, [stream, refVoice]);

    const handleVoiceChat = () => {
        if (!initRecording) {
            startRecording();
        } else {
            saveRecording();
        }
    };

    const uploadVoice = async (blob) => {
        try {
            const file = new File([blob], "test.wav", {
                type: "audio/wav",
            });
            const formData = new FormData();
            formData.append("file", file);
            let headers = {
                Authorization: `Bearer ${token}`,
            };
            const { data, status } = await axios.post(
                `${baseUrl}/api/hirax/upload_file`,
                formData,
                {
                    headers: headers,
                }
            );
            if (status === 200) {
                socket.timeout(500).emit("sendVoiceFromWidget", {
                    upload_data: JSON.stringify(data),
                });
                setInitRecording(false);
                setBlob(null);
                /*  setRecordings([]) */
            }
        } catch (error) {}
    };
    useEffect(() => {
        if (blob !== null) {
            uploadVoice(blob);
        }
    }, [blob]);

    useEffect(() => {
        socket.on("sendVoiceFromWidgetResponse", function (res) {
            setMessages([
                ...messages,
                {
                    from: "me",
                    timestamp: res.timestamp,
                    msg: "",
                    id: res.id,
                    file: res.file,
                    reply_message: res?.reply_message,
                    buttons: res?.buttons,
                },
            ]);
        });
    });

    useEffect(() => {
        const handleMessage = (res) => {
            if (res?.message) {
                socket
                    .timeout(500)
                    .emit("sendMessageFromWidget", { message: res.message });
            }
        };
        socket.on("sendVoiceFromWidgetResponse", handleMessage);

        return () => {
            socket.off("sendVoiceFromWidgetResponse", handleMessage);
        };
    }, [socket]);0
    const selectFile = (event) => {
        setSelectedFiles(event.target.files);
    };
    const formatBytes = (bytes, decimals = 2) => {
        if (!+bytes) return "0 بایت";

        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ["بایت", "کیلو بایت", "مگابایت"];

        const i = Math.floor(Math.log(bytes) / Math.log(k));

        return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${
            sizes[i]
        }`;
    };
    const controller = new AbortController();

    const cancelUploadFile = () => {
        cancelTokenSource.cancel("لغو شد");
        controller.abort();
        setSelectedFiles([]);
        setProgress(0);
    };
    const sendUploadFile = async () => {
        try {
            let currentFile = selectedFiles[0];
            let formData = new FormData();
            formData.append("file", currentFile);
            let headers = {
                Authorization: `Bearer ${token}`,
            };
            const { data, status } = await axios.post(
                `${baseUrl}/api/hirax/upload_file`,
                formData,
                {
                    headers: headers,
                    cancelToken: cancelTokenSource.token,
                    signal: controller.signal,
                    onUploadProgress: (data) => {
                        //Set the progress value to show the progress bar
                        setProgress(
                            Math.round((100 * data.loaded) / data.total)
                        );
                    },
                }
            );
            if (status === 200) {
                socket.timeout(500).emit("sendFileFromWidget", {
                    message: "",
                    upload_data: JSON.stringify(data),
                });
                scrollToBottom();
                setSelectedFiles([]);
                setProgress(0);
            }
        } catch (error) {
            if (axios.isCancel(error)) {
                cancelTokenSource.cancel("آپلود لغو شد!؟");
            }
        }
    };
    /*     cancelTokenSource.cancel("آپلود لغو شد!؟");
     */

    useEffect(() => {
        socket.on("sendFileFromWidgetResponse", function (res) {
            scrollToBottom();
            setMessages([
                ...messages,
                {
                    user_type: "widget",
                    id: res.id,
                    file: res.file,
                    timestamp: res.timestamp,
                    message: res.message,
                },
            ]);
        });
    });
    const [replyMessage, setReplyMessage] = useState({
        replyText: "",
        replyId: "",
    });
    const { replyId, replyText } = replyMessage;
    const handlereplyMessage = (id, message) => {
        setReplyMessage({
            replyId: id,
            replyText: message?.message || message?.msg,
        });
        /*  setreplyMessage(message) */
    };
    //sendMessageFromAdmin
    // sendMessageFromWdiget
    const handleSendReplyMessage = (e) => {
        e.preventDefault();
        if (message.trim()) {
            socket.timeout(500).emit("sendMessageFromWidget", {
                message: message,
                reply_id: replyId,
            });
            setMessage("");
            setReplyMessage({
                replyId: "",
                replyText: "",
            });
        }
    };

    return (
        <S.ContainerWidget isOpen={isOpen} zIndex={zIndex}>
            {isOpen && (
                <S.WrapperWidget isOpen={isOpen}>
                    <HeaderWidget
                        templateConfig={templateConfig}
                        appName={appName}
                        name={name}
                        subTitle={subTitle}
                        baseUrl={baseUrl}
                        onClose={handleCloseMessagebox}
                    />

                    <S.MessageBoxWidget
                        backgroundColorWidget={
                            templateConfig?.backgroundColorWidget
                        }
                    >
                        <S.MessagesBoxListWidget>
                           {/*  <S.DisplayFlexBoxWidget
                                flexDirection="column"
                                marginBottom={10}
                                key={message.id}
                            >
                                
                                <S.MessageTimeWidget>
                                    
                                    {getTime(message.timestamp)}
                                </S.MessageTimeWidget>
                            </S.DisplayFlexBoxWidget> */}
                            {messages?.length !== 0 && (
                                <S.ChatBoxWidget>
                                    {messages?.map((message, index) => {
                                        return (
                                            <Fragment key={index}>
                                                <PartView
                                                    templateConfig={
                                                        templateConfig
                                                    }
                                                    baseUrl={baseUrl}
                                                    handleSendText={
                                                        handleSendText
                                                    }
                                                    createShowIcon={
                                                        createShowIcon
                                                    }
                                                    getTime={getTime}
                                                    message={message}
                                                    messagesEndRef={
                                                        messagesEndRef
                                                    }
                                                    handlereplyMessage={
                                                        handlereplyMessage
                                                    }
                                                />
                                            </Fragment>
                                        );
                                    })}
                                </S.ChatBoxWidget>
                            )}
                        </S.MessagesBoxListWidget>
                        {!selectedFiles[0] ? (
                            <S.SendboxWidgetForm
                                id="sendMessage"
                                onSubmit={
                                    replyText
                                        ? handleSendReplyMessage
                                        : handleSubmitMessage
                                }
                            >
                                {replyMessage?.replyText ? (
                                    <S.ReplyMessageContainer>
                                        <div
                                            onClick={() =>
                                                setReplyMessage({
                                                    replyId: "",
                                                    replyText: "",
                                                })
                                            }
                                        >
                                            <CloseReplySvg />
                                        </div>
                                        <S.ReplyMessageText>
                                            {replyMessage?.replyText}
                                        </S.ReplyMessageText>
                                    </S.ReplyMessageContainer>
                                ) : null}
                                <S.SendboxWidgetContainer>
                                     {microphone ? (
                                        <S.SendboxWidgetIcon
                                            onClick={handleVoiceChat}
                                            isOpenVoice={initRecording}
                                        >
                                            {initRecording ? (
                                                <RecordAction />
                                            ) : (
                                                <RecordSVG />
                                            )}
                                        </S.SendboxWidgetIcon>
                                    ) : null} 

                                    {initRecording ? (
                                        <S.SendMesageBoxVoice>
                                            <S.SendMesageBoxVoiceWapper>
                                                <S.SendMesageBoxVoiceTitle>
                                                    در حال ضبط
                                                </S.SendMesageBoxVoiceTitle>
                                                <S.SendMesageBoxVoiceAlert></S.SendMesageBoxVoiceAlert>
                                            </S.SendMesageBoxVoiceWapper>
                                        </S.SendMesageBoxVoice>
                                    ) : null}

                                    <Input
                                        placeholder="پیام خود را بنویسید"
                                        type={"text"}
                                        value={message}
                                        autoComplete="off"
                                        onChange={(e) => {
                                            setMessage(e.target.value);
                                        }}
                                    />

                                      <S.ChoseFileBtn htmlFor="upload-file">
                                        <ChoseFileSvg
                                            width="16px"
                                            height="16px"
                                        />
                                        <input
                                            type="file"
                                            onChange={selectFile}
                                            hidden
                                            id="upload-file"
                                        />
                                    </S.ChoseFileBtn> 
                                </S.SendboxWidgetContainer>
                            </S.SendboxWidgetForm>
                        ) : (
                            <ProgressWidget
                                name={selectedFiles[0]?.name}
                                size={formatBytes(selectedFiles[0]?.size)}
                                onClose={cancelUploadFile}
                                progress={progress}
                                sendUploadFile={sendUploadFile}
                            />
                        )}
                    </S.MessageBoxWidget>
                </S.WrapperWidget>
            )}

            {!isOpen ? (
                <S.WidgetIconWrapperWidget isOpen={isOpen} className="active">
                    <S.IconWidget
                        onClick={handleShowMessagebox}
                        backgroundColor={templateConfig?.primaryColor}
                    >
                        <CommentSVG />
                    </S.IconWidget>
                </S.WidgetIconWrapperWidget>
            ) : null}

            <div className="opinions_box">
                <div className="opinions_box__view-more"></div>
            </div>
        </S.ContainerWidget>
    );
};
