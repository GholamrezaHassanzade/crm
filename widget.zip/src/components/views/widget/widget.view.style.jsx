// * Import Tools
import styled from "@emotion/styled/macro";

const ContainerWidget = styled.div`
    width: 420px !important;
    /* height: ${({ isOpen }) => (isOpen ? "unset" : "600px")}; */
    position: fixed !important;
    bottom: 15px !important;
    right: 15px !important;
    direction: rtl !important;
    display: flex !important;
    flex-direction: column !important;
    justify-content: space-between !important;
    z-index: ${({ zIndex }) => (zIndex ? zIndex : 500)} !important;
    box-shadow: 0px 0px 16px 0px rgba(0, 0, 0, 0.25) !important;
    border-radius: 16px !important;
    @media (max-width: 768px) {
        width: 100% !important;
        top: 0 !important;
        left: 0 !important;
        right: 0 !important;
        bottom: 0 !important;
    }
`;

const DisplayFlexBoxWidget = styled.div`
    display: flex !important;
    flex-direction: ${({ flexDirection }) => flexDirection ?? "unset"} !important;
    align-items: ${({ alignItems }) => alignItems ?? "unset"} !important;
    justify-content: ${({ justifyContent }) => justifyContent ?? "unset"} !important;
    margin-bottom: ${({ marginBottom }) => `${marginBottom}px` ?? "unset"} !important;
`;
const WrapperWidget = styled.div`
    box-shadow: 0px 15px 20px ${({ theme }) => theme.BOX_SHADOW_PRIMARY} !important;
    overflow: hidden !important;
    display: flex !important;

    flex-direction: column !important;
    border-radius: 16px !important;
    height: 90% !important;
    background-color: #fff !important;
    position: relative !important;

    @media (max-width: 768px) {
        border-radius: 0 !important;
        height: 100% !important;
    }
`;

const WidgetIconWrapperWidget = styled.div`
    display: ${({ isOpen }) => (isOpen ? "none" : "block")} !important;
    &.active {
        position: fixed !important;
        right: 15px !important;
        bottom: 15px !important;
    }
`;

/* message box */
const MessageBoxWidget = styled.div`
    height: 100% !important;
    display: flex !important;
    flex-direction: column !important;
    justify-content: space-between !important;
    padding-bottom: 80px !important;
    background-color: ${({ theme, backgroundColorWidget }) =>
        backgroundColorWidget ? backgroundColorWidget : theme.WHITE} !important;
    /*  position: relative; */
    /* height: 500px; */
`;

const SendboxWidgetForm = styled.form`
    /*  height: 60px; */
    padding: 5px 0 !important;
    border-bottom-left-radius: 16px !important;
    border-bottom-right-radius: 16px !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    flex-direction: column !important;
    padding: 5px 15px !important;
    position: absolute !important;
    bottom: 10px !important;
    right: 10px !important;
    width: 94% !important;
    left: 10px !important;
    background: #fff !important;
    box-shadow: 0px 0px 8px ${({ theme }) => theme.BOX_SHADOW_SECONDEY} !important;
    border-radius: 16px !important;
    overflow: hidden !important;
    @media (max-width: 768px) {
        border-radius: 0 !important;
    }
`;

const SendboxWidgetContainer = styled.div`
    display: flex !important;
    align-items: center !important;
    width: 100% !important;

    position: relative !important;
`;

const ReplyMessageContainer = styled.div`
    display: flex;
    flex-direction: row-reverse;
    align-items: center;
    padding: 8px !important;
    background: #e5e5ea !important;
    border-radius: 16px !important;
    justify-content: space-between !important;
    width: 100% !important;
`;
const ReplyMessageText = styled.span`
    max-height: 40px !important;
    overflow-y: auto !important;
    font-family: "YekanBakh" !important;
    color: var(--neutral-primarytext, #09080e) !important;
    text-align: right !important;
    /* body 2/regular */
    font-size: 14px !important;
    font-style: normal !important;
    font-weight: 400 !important;
    line-height: 24px !important;
    word-wrap: break-word !important;
    overflow-y: auto !important;
    scrollbar-width: thin !important; 

    ::-webkit-scrollbar {
        width: 1px !important;
    }
`;
const SendboxWidgetIcon = styled.div`
    cursor: pointer !important;
    width: 32px !important;
    height: 32px !important;
    border-radius: 50% !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    position: absolute !important;
    right: -7px !important;
    background-color: ${({ isOpenVoice, theme }) =>
        isOpenVoice ? theme.PRIMARY : theme.WHITE} !important;
    z-index: 5 !important;
`;

const SendMesageBoxVoice = styled.div`
    position: absolute !important;
    width: 95% !important;
    height: 32px !important;
    background-color: red !important;
    z-index: 4 !important;
    right: 9px !important;
    border-radius: 16px !important;
    background-color: #cfcbde !important;
    display: flex !important;
    align-items: center !important;
    justify-content: flex-end !important;
`;
const SendMesageBoxVoiceWapper = styled.div`
    display: flex !important;
    align-items: center !important;
    gap: 8px !important;
    padding: 0 16px !important;
    width: 100% !important;
    justify-content: flex-end !important;
`;
const SendMesageBoxVoiceTitle = styled.p`
    font-family: "YekanBakh" !important;
    font-size: 12px !important;
    font-style: normal !important;
    font-weight: 400 !important;
`;
const SendMesageBoxVoiceAlert = styled.div`
    width: 13px !important;
    height: 13px !important; 
    background-color: #dc362e !important;
    border-radius: 50% !important;
`;
const MessagesBoxListWidget = styled.div`
    width: 100% !important;
    display: flex !important;
    flex-direction: column-reverse !important;
    width: 100% !important;
    height: 450px !important;
    overflow-y: auto !important;
    scrollbar-width: thin !important; /* "auto" or "thin" */

    ::-webkit-scrollbar {
        width: 1px !important;
    }
    @media (max-width: 768px) {
        height: calc(100vh - 150px) !important;
        /*  height: 90%; */
    }
`;
const ChatBoxWidget = styled.div`
    display: flex !important;
    flex-direction: column !important;
    padding: 0 !important;
    list-style: none !important;
    direction: rtl !important;
    padding: 80px 15px !important;
    justify-content: end !important;
`;

const SharedWidgetRight = styled.div`
    position: relative !important;
    padding: 8px 16px !important;
    word-wrap: break-word !important;
    align-self: flex-start !important;
    background: #ffd00f !important;
    margin-right: 6px !important;
    border-radius: 25px 25px 0 25px !important;
    font-family: "YekanBakh" !important;
    font-size: 13px !important;
    background-color: rgba(94, 83, 144, 1) !important;

    &:before,
    &:after {
        position: absolute !important;
        bottom: 0 !important;
        content: "" !important;
    }
`;
const SharedWidgetLeft = styled.div`
    position: relative !important;
    padding: 8px 16px !important;
    word-wrap: break-word !important;
    align-self: flex-end !important;
    background: #e5e5ea !important;
    color: #000 !important;
    margin-left: 6px !important;
    border-radius: 25px 25px 25px 0 !important;
    font-family: "YekanBakh" !important;
    font-size: 13px !important;
    max-width: 340px !important;
    position: relative !important;

    &:last-child {
        margin-bottom: 15px !important;
    }
`;

const SharedWidgetRightToggleWapper = styled.div`
    position: absolute !important;
    right: 10px !important;
    top: 10px !important;
    display: flex !important;
    align-items: center !important;
    flex-direction: row-reverse !important;
    svg {
        height: 10px !important;
        cursor: pointer !important;
    }
`;

const SharedWidgetLeftToggleWapper = styled.div`
    position: absolute !important;
    right: 10px !important;
    top: 15px !important;
    svg {
        height: 10px !important;
        cursor: pointer !important;
    }
`;

const MessagWidget = styled.div`
    font-family: "YekanBakh" !important;
    color: #443d3d !important;
    font-size: 13px !important;
    font-weight: 500 !important;
    word-wrap: break-word !important;
    max-width: 300px !important;
    margin-top: 15px !important;
    color: #fff !important;

    span {
        color: #fff !important;
    }
`;
const MessageTimeWidget = styled.span`
    font-family: Arial, Helvetica, sans-serif !important;
    font-size: 11px !important;
    font-weight: 100 !important;
    color: #000 !important;
    margin: 0 5px !important;
`;

const MessageBoxWidgetButtonConatiner = styled.div`
    display: flex !important;
    flex-direction: column !important;
    justify-content: center !important;
    margin-top: ${({ buttons }) => (buttons ? "15px" : 0)} !important;
`;

const ReplyContiner = styled.div`
    width: 100% !important;
    display: flex !important;
    flex-direction: column !important;
    justify-content: space-between !important;
    padding: 5px !important;
`;

const ReplyContinerReyplyMessage = styled.span`
    max-width: 100% !important;
    text-overflow: ellipsis !important;
    white-space: nowrap !important;
    overflow: hidden !important;
    display: block !important;
    position: relative !important;
    padding: 0px 0px 0px 10px !important;
    &:after {
        position: absolute !important;
        content: "";
        background-color: ${({ theme, status }) =>
            status === "user" ? "#e5e5ea" : theme.PRIMARY} !important;
        width: 2px !important;
        left: 0 !important;
        height: 100% !important;
        top: 9px !important;
        bottom: 0 !important;
        top: 0 !important;
    }
`;

const IconWidget = styled.div`
    width: 60px !important;
    height: 60px !important;
    /* background-color: ${({ theme, backgroundColor }) =>
        backgroundColor ? backgroundColor : theme.PRIMARY} !important; */
    background-color: rgba(94, 83, 144, 1) !important;
    border-radius: 50% !important;
    overflow: hidden !important;
    cursor: pointer !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
`;

const ChoseFileBtn = styled.label`
    border: 0 !important;
    outline: 0 !important;
    background-color: transparent !important;
    cursor: pointer !important;
    width: 32px !important;
    height: 32px !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    /*  svg {
        width: 20px !important;
        height: 20px !important;
    } */
`;

const LikeAndDisLikeContainer = styled.div`
    display: flex !important;
    align-items: center !important;
    gap: 2px !important;
    position: absolute !important;
    bottom: -19px !important;
`;
const LikeAndDisLikeWrrapper = styled.div`
    width: 32px !important;
    height: 32px !important;
    border-radius: 50%  !important;
    cursor: pointer !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    background-color: #e5e5ea !important;
`;

export const WidgetViewStyle = {
    ContainerWidget,
    DisplayFlexBoxWidget,
    WrapperWidget,
    WidgetIconWrapperWidget,
    IconWidget,
    MessageBoxWidget,
    MessagesBoxListWidget,
    SendboxWidgetForm,
    SendboxWidgetContainer,
    ReplyMessageContainer,
    ReplyMessageText,
    SendMesageBoxVoice,
    SendMesageBoxVoiceWapper,
    SendMesageBoxVoiceTitle,
    SendMesageBoxVoiceAlert,
    SendboxWidgetIcon,
    ChatBoxWidget,
    SharedWidgetRight,
    SharedWidgetLeft,
    SharedWidgetLeftToggleWapper,
    SharedWidgetRightToggleWapper,
    MessageBoxWidgetButtonConatiner,
    MessageTimeWidget,
    MessagWidget,
    ReplyContiner,
    ReplyContinerReyplyMessage,
    ChoseFileBtn,
    LikeAndDisLikeContainer,
    LikeAndDisLikeWrrapper,
};
