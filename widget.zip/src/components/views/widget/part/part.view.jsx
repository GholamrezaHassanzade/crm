import React from "react";

import { WidgetViewStyle as S } from "../widget.view.style";

import {
    AttachmentSVG,
    ReplySVG,
    ToggleSVG,
} from "../../../../constants/images";
import { AudioPlayer, RobotButton } from "../../../common/partials";

export const PartView = ({
    message,
    baseUrl,
    handleSendText,
    createShowIcon,
    getTime,
    messagesEndRef,
    handlereplyMessage,
    templateConfig,
}) => {
    return (
        <>
            {message.from === "me" || message.user_type === "widget" ? (
                <>
                    <S.DisplayFlexBoxWidget
                        flexDirection="column"
                        marginBottom={10}
                        key={message.id}
                    >
                        <S.SharedWidgetRight>
                            {message?.file?.mimetype === "audio/x-wav" ? (
                                <AudioPlayer
                                    song={`${baseUrl}${message.file.url}`}
                                />
                            ) : (
                                <S.MessagWidget>
                                    {/*  <S.SharedWidgetRightToggleWapper
                                        onClick={() =>
                                            handlereplyMessage(
                                                message.id,
                                                message
                                            )
                                        }
                                    >
                                        <ReplySVG fill="#e5e5ea" />
                                    </S.SharedWidgetRightToggleWapper> */}

                                    {message?.reply_message ? (
                                        <S.ReplyContinerReyplyMessage
                                            status={"user"}
                                        >
                                            {" "}
                                            {message?.reply_message?.message
                                                ? message?.reply_message
                                                      ?.message
                                                : null}{" "}
                                        </S.ReplyContinerReyplyMessage>
                                    ) : null}

                                    {message.msg || message.message}

                                    {message.file ? (
                                        message.file.mimetype.startsWith(
                                            "image"
                                        ) ? (
                                            <a
                                                href={`${baseUrl}${message.file.url}`}
                                                target="_blank"
                                                style={{
                                                    display: "block",
                                                }}
                                                download
                                            >
                                                <img
                                                    style={{
                                                        width: "145px",
                                                        height: "145px",
                                                    }}
                                                    src={`${baseUrl}/${message.file.url}`}
                                                    alt={message.file.filename}
                                                />
                                            </a>
                                        ) : (
                                            <a
                                                href={`${baseUrl}${message.file.url}`}
                                                target="_blank"
                                                download={true}
                                                className="attach__file__link"
                                            >
                                                <AttachmentSVG stroke="#ffffff" />
                                                <span>
                                                    {message?.file?.filename}
                                                </span>
                                            </a>
                                        )
                                    ) : null}
                                </S.MessagWidget>
                            )}
                        </S.SharedWidgetRight>
                        <S.MessageTimeWidget>
                            {getTime(message.timestamp)}
                        </S.MessageTimeWidget>
                    </S.DisplayFlexBoxWidget>

                    <div ref={messagesEndRef} />
                </>
            ) : (
                <>
                    <S.DisplayFlexBoxWidget
                        flexDirection="column"
                        alignItems="end"
                        marginBottom={10}
                        key={message.id}
                    >
                        <S.SharedWidgetLeft
                            replyMessage={message?.reply_message?.message}
                        >
                            {/* {message?.user_type !== "bot" ? ( */}
                            {/*  <S.SharedWidgetLeftToggleWapper
                                onClick={() =>
                                    handlereplyMessage(message.id, message)
                                }
                            >
                                <ReplySVG />
                            </S.SharedWidgetLeftToggleWapper> */}
                            {/*  ) : null} */}

                            <S.ReplyContiner>
                                {message?.reply_message ? (
                                    <S.ReplyContinerReyplyMessage>
                                        {" "}
                                        {message?.reply_message?.message
                                            ? message?.reply_message?.message
                                            : null}{" "}
                                    </S.ReplyContinerReyplyMessage>
                                ) : null}

                                <span>
                                    {message.msg || message.message}
                                    {message?.file?.mimetype ===
                                    "audio/x-wav" ? (
                                        <AudioPlayer
                                            song={`${baseUrl}${message.file.url}`}
                                        />
                                    ) : message.file ? (
                                        message.file.mimetype.startsWith(
                                            "image"
                                        ) ? (
                                            <a
                                                href={`${baseUrl}${message.file.url}`}
                                                target="_blank"
                                                style={{
                                                    display: "block",
                                                }}
                                                download
                                            >
                                                <img
                                                    style={{
                                                        width: "145px",
                                                        height: "145px",
                                                    }}
                                                    src={`${baseUrl}/${message.file.url}`}
                                                    alt={message.file.filename}
                                                />
                                            </a>
                                        ) : (
                                            <a
                                                href={`${baseUrl}${message.file.url}`}
                                                target="_blank"
                                                download={true}
                                                className="attach__file__link"
                                            >
                                                <AttachmentSVG />
                                                <span>
                                                    {message?.file?.filename}
                                                </span>
                                            </a>
                                        )
                                    ) : null}
                                   {/*  {message.file ? (
                                        message.file.mimetype.startsWith(
                                            "image"
                                        ) ? (
                                            <a
                                                href={`${baseUrl}${message.file.url}`}
                                                target="_blank"
                                                style={{
                                                    display: "block",
                                                }}
                                                download
                                            >
                                                <img
                                                    style={{
                                                        width: "145px",
                                                        height: "145px",
                                                    }}
                                                    src={`${baseUrl}/${message.file.url}`}
                                                    alt={message.file.filename}
                                                />
                                            </a>
                                        ) : (
                                            <a
                                                href={`${baseUrl}${message.file.url}`}
                                                target="_blank"
                                                download={true}
                                                className="attach__file__link"
                                            >
                                                <AttachmentSVG />
                                                <span>
                                                    {message?.file?.filename}
                                                </span>
                                            </a>
                                        )
                                    ) : null} */}
                                </span>
                            </S.ReplyContiner>

                            {message?.buttons?.length === 0 ||
                            message?.buttons?.undefined === undefined ||
                            message?.buttons?.length !== 0 ? (
                                <>
                                    {message?.buttons?.map((itm, index) => {
                                        if (
                                            itm?.title === "like" ||
                                            itm?.title === "dislike"
                                        ) {
                                            return (
                                                <>{createShowIcon(itm.title)}</>
                                            );
                                        } else {
                                            return (
                                                <S.MessageBoxWidgetButtonConatiner
                                                /*  buttons={message?.buttons} */
                                                >
                                                    <RobotButton
                                                        key={index + 1}
                                                        onClick={() =>
                                                            handleSendText(
                                                                itm.payload,
                                                                index
                                                            )
                                                        }
                                                    >
                                                        {" "}
                                                        {itm.title}
                                                        {/* {createShowIcon(itm.title)} */}
                                                    </RobotButton>
                                                </S.MessageBoxWidgetButtonConatiner>
                                            );
                                        }
                                    })}
                                </>
                            ) : null}
                        </S.SharedWidgetLeft>
                        <S.MessageTimeWidget>
                            {getTime(message.timestamp)}
                        </S.MessageTimeWidget>
                    </S.DisplayFlexBoxWidget>

                    <div ref={messagesEndRef} />
                </>
            )}
        </>
    );
};
