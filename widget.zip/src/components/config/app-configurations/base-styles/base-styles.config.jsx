// * Import Casual modules
import React from "react";
// * Import Tools
import { css } from "@emotion/react";

// * Import Tools
import { Global } from "@emotion/react";
import { BaseStylesConfigReset } from "./base-styles.config.reset";

export const BaseStylesConfig = ({baseUrl}) => {
    return (
        <>
            <Global styles={BaseStylesConfigReset} />
            <Global
                styles={css`
                    @font-face {
                        font-family: YekanBakh;
                        font-style: normal;
                        font-weight: 500;
                        src: url(${baseUrl}/cdn/hirax-cdn/YekanBakhFaNum03Light.ttf);
                    }
                `}
            />
        </>
    );
};
