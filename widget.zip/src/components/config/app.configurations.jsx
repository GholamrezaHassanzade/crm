// * Import Casual modules
import React from "react";
import { EmotionConfig } from "./app-configurations/emotion/emotion.config";
import { BaseStylesConfig } from "./app-configurations/base-styles/base-styles.config";

export const AppConfigurations = ({ children,baseUrl }) => {
    return (
        <>
            <BaseStylesConfig  baseUrl={baseUrl}/>
            <EmotionConfig>{children}</EmotionConfig>
        </>
    );
};
