export const regexPatterns = {
    mobile: /^[0][9][0-9][0-9]{8,8}$/,
    onlyNumber: /^\d+$/,
    alphanumeric: /^[a-zA-Z0-9]+$/,
    onlyString: /^[a-zA-Z]+$/,
}