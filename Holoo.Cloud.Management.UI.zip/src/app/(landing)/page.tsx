import { Register } from '@/components/_organisms';
export default function Home() {
  return (
    <>
      <Register />
    </>
  );
}
