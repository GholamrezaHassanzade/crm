// /app/dashboard/page.tsx
import React from 'react';

const DashboardPage = () => {
  return (
    <div>
      <h1>Hello, Dashboard!</h1>
    </div>
  );
};

export default DashboardPage;
